import React, { useState, useEffect } from "react";
import { Button, Text, TextInput, View, FlatList } from "react-native";
import Axios from 'axios'

const Quiz5 = (props) => {
  const [loading,setLoading] = useState(true)
  const [text, setText] = useState('');
  const [data,setData] = useState([]);
  const [refreshPost, setRefreshPost] = useState('');
  const [nameOfRepo, setnameOfRepo] =useState('');
  const [reposLength,setReposLength] = useState(0);
  const [showButton, setshowbutton] = useState(true)
  const [showRep,setshowRep] = useState('false')
  const [post, setPost] = useState('')
  const [bb,setBB] = useState("")
  


  // const getRepoData = async (userName) => {
  //   try{
  //     let result = await fetch(`https://glacial-hamlet-05511.herokuapp.com`)
  //     let cdata = await result.json()
  //     cdata = cdata.sort(covid_before)
  //     setnameOfRepo(cdata)
  //     setData(cdata)
  //     setLoading(false)
      
  //     if (userName == ''){
  //       setReposLength(1)
  //     } else{
  //       setReposLength(cdata.length)
  //     }
  //   }catch(e){
  //     console.log(`error in getRepoData: ${JSON.stringify(e)}`)
  //   }


  // }


const getPosts = () => {
        Axios.post("https://glacial-hamlet-05511.herokuapp.com/posts",{bboard:bb})
        .then(function(response){
            setPost(response.data)
        })
        .catch(err => console.log(err))
    }



const getBoards = () => {
        Axios.get("https://glacial-hamlet-05511.herokuapp.com/bboardNames")
        .then(function(response){
            setBB(response.data)
        })
    }



  function covid_before(a, b) {
    var keyA = new Date(a.created_at),
      keyB = new Date(b.created_at);
    // Compare the 2 dates
    //if (a.state<b.state) return -1;
    //if (a.state>b.state) return 1;
    if (keyA < keyB) return 1;
    if (keyA > keyB) return -1;
    return 0;
  }

  // useEffect(() => {
  //   getRepoData(userName)
  // }, [userName]);

  const renderItem = ({item}) => {
    return (
      <View style={{flexDirection:'row'}}>
        <Text style={{flex:1,textAlign:'right'}}>{item['name']}</Text>
     </View>

     )}


  let repoButton = " "

  if (showButton) {
    repoButton = 
    <View style={{  alignItems:  'start',}}>
      <Button alignItems='left' title="refresh boards" onPress ={()=> {setshowRep(true) ,setRefreshPost(text) , setshowbutton(false)}}  />
      <Button alignItems='auto' title="BB1" color='red' />
      <Button alignItems='auto' title="BB2" color='red' />
      <Button alignItems='auto' title="BB3" color='red' />
      <Button alignItems='auto' title="BB4" color='red' />
    </View>
    
  } else {
    repoButton =
    <View style={{  alignItems:  'start',}}>
        <Button title="hide repositories"  onPress ={()=> {setshowRep(false) , setshowbutton(true)}} />
    </View>
}

  let repo = ''
    if (showRep){
      repo = 
        <FlatList
          data={nameOfRepo}
          renderItem={renderItem}
          keyExtractor={item => item.created_at}
        />
    } else {
      repo = 
      <View style={{flexDirection:'row', padding: 25 , margin:15,alignItems: 'flex-spacebetween',backgroundColor:'#aaa'}}>
        <Text style={{fontSize:25}}>NONE</Text>
      </View>
  }


  return (
    <View style={{padding:20,margin:20,border: 'none'}}>
      <Text style={{fontSize:30,color:'red', backgroundColor: 'black', alignItem:"center"}}>
       BBViewer
      </Text>
      <View style={{flexDirection:'row',justifyContent: 'left'}}>
        <Text style={{fontSize:15}}>
        Selected BBoard: </Text>
        <TextInput
          style={{height: 40, fontSize:'20'}}
          placeholder=""
          onChangeText={text => {setText(text)}}
        />
      </View>

      {repoButton}

      <View style={{flexDirection:'row',flex:''}}>
        <Text style={{flex:'1',backgroundColor:'#eee'}}></Text>

     </View>
     
     {repo}

      <View style={{flexDirection:'column',justifyContent: 'bottom'}}>
        <Text style={{fontSize:20}}>
        DEBUGGING </Text>
        <Text> bb: {refreshPost} </Text>
        <Text> showReps: {showRep} </Text>
        <Text> bb.length: {reposLength} </Text>
        <Text> Post = {post} </Text>
        
    </View>

    </View>


    
  );
}



export default Quiz5;
